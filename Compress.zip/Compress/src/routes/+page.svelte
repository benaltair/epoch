<script>
	import Container from '$lib/Timeline/Container.svelte';
	import Navigator from '$lib/Timeline/Navigator.svelte';
</script>

<Container>
	<Navigator firstYear={1844} lastYear={2044} />
</Container>
